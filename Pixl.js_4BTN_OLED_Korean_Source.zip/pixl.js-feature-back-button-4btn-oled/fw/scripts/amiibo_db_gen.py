"""Generate bilingual firmware tables from the reviewed local CSV database.

Generation is offline and deterministic. Update the CSV explicitly before building.
"""
import csv,json,re
from pathlib import Path
fw=Path(__file__).resolve().parent.parent
def read(name): return list(csv.reader((fw/'data'/name).open(encoding='utf8')))
def c(s): return json.dumps(s,ensure_ascii=False)
amiibos=sorted(read('amiidb_amiibo.csv'));games=read('amiidb_game.csv');links=read('amiidb_link.csv')
ids={a[0] for a in amiibos}; gids={g[0] for g in games}
assert len(ids)==len(amiibos) and all(re.fullmatch('[0-9a-f]{16}',a) for a in ids)
assert len(gids)==len(games) and all(0<int(g)<256 for g in gids)
assert len({(r[0],r[1]) for r in links})==len(links)
assert all(r[0] in gids and r[1] in ids and len(r)==4 for r in links)
linked={r[1] for r in links}
links.extend(['255',a[0],'',''] for a in amiibos if a[0] not in linked)
def emit(filename,typ,name,rows,sentinel,tail=''):
    (fw/'application/src/amiidb'/filename).write_text('/* Generated from reviewed CSV data. */\n#include "db_header.h"\nconst '+typ+' '+name+'[] = {\n'+''.join('{'+','.join(row)+'},\n' for row in rows)+'{'+sentinel+'}\n};\n'+tail,encoding='utf8')
emit('db_amiibo.c','db_amiibo_t','amiibo_list',(['0x'+a[:8],'0x'+a[8:],c(en),c(ko)] for a,en,ko in amiibos),'0,0,0,0','const size_t amiibo_list_size = sizeof(amiibo_list) / sizeof(db_amiibo_t) - 1;\n')
emit('db_link.c','db_link_t','link_list',([g,'0x'+a[:8],'0x'+a[8:],c(en),c(ko)] for g,a,en,ko in links),'0,0,0,0,0')
def count(gid,seen=None):
    seen=set() if seen is None else seen
    assert gid not in seen,'Game parent cycle'
    return sum(r[0]==gid for r in links)+sum(count(g[0],seen|{gid}) for g in games if g[1]==gid)
emit('db_game.c','db_game_t','game_list',([g,p,c(en),c(ko),order,str(count(g))] for g,p,en,ko,order in games),'0,0,0,0,0,0')
print(f'Generated {len(amiibos)} amiibos, {len(games)} game entries, {len(links)} links.')

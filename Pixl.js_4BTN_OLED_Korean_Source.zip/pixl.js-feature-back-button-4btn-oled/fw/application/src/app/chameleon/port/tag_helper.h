#ifndef TAG_HELPER_H
#define TAG_HELPER_H

#include "nfc_14a.h"
#include "nfc_mf0_ntag.h"
#include "nfc_mf1.h"
#include "tag_base_type.h"

#define TAG_TYPE_HF_MAX 13
#define SLOT_MAX TAG_MAX_SLOT_NUM

typedef struct {
    tag_specific_type_t tag_type;
    const char *short_name;
    const char *long_name;
    uint16_t data_size;
} tag_specific_type_name_t;

typedef enum {
    TAG_GROUP_UNKNOWN = 0,
    TAG_GROUP_MIFARE,
    TAG_GROUP_NTAG,
} tag_group_type_t;

extern const tag_specific_type_t hf_tag_specific_types[];

const tag_specific_type_name_t *tag_helper_get_tag_type_name(tag_specific_type_t tag_type);
nfc_tag_14a_coll_res_reference_t *tag_helper_get_active_coll_res_ref();
tag_specific_type_t tag_helper_get_active_tag_type();
void tag_helper_format_uid(char *buff, uint8_t *uid, uint8_t uid_len);
const char *tag_helper_get_mf_write_mode_name(nfc_tag_mf1_write_mode_t write_mode);
void tag_helper_load_coll_res_from_block0();

void tag_helper_get_nickname(char *buff, size_t buff_len);
int32_t tag_helper_set_nickname(const char *nickname);

size_t tag_helper_get_active_tag_data_size();
uint8_t *tag_helper_get_active_tag_memory_data();

void tag_helper_generate_uid();

bool tag_helper_is_defult_slot();

bool tag_helper_valid_default_slot();

void tag_helper_set_slot_num(uint8_t slot_num);

#endif
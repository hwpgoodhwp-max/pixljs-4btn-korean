# Pixl.js 4-button OLED Korean DB firmware source

This tree combines the `feature/back-button-4btn-oled` board support with the
Korean translations from `Gt5588/Amiibo-Pixl.js_Kor`.

## Target

- Board: `OLED_4BTN`
- Languages: English and Korean only
- Default language after a settings reset: Korean (`ko_KR`)
- Fourth button: Back / long-press sleep, as implemented by the 4-button branch
- Korean glyph source: the patched BDF from `Gt5588/Amiibo-Pixl.js_Kor`
- Korean database: 932 Amiibo names and 76 game names recovered from the
  user-supplied `pixjs_2.16.0_dbko_OLED_v216001` firmware
- Compatibility/reward descriptions remain English, matching the supplied DBKO firmware

## Font fix

The Korean BDF must be used instead of the similarly named upstream BDF. The
upstream file does not contain the complete patched glyph set required by the
Korean menu. This source tree includes the corrected font and regenerated u8g2
font data.

## Build

Initialize all Git submodules and use the upstream nRF52 SDK build container:

```sh
git submodule update --init --recursive
cd fw
make all BOARD=OLED_4BTN RELEASE=1
```

The OTA package is generated under `fw/_build/`.

Do not flash this build onto LCD or standard three-button OLED hardware.

# Pixl.js 4-button OLED Korean firmware source

This tree combines the `feature/back-button-4btn-oled` board support with the
Korean translations from `Gt5588/Amiibo-Pixl.js_Kor`.

## Target

- Board: `OLED_4BTN`
- Default language after a settings reset: Korean (`ko_KR`)
- Fourth button: Back / long-press sleep, as implemented by the 4-button branch

## Build

Initialize all Git submodules and use the upstream nRF52 SDK build container:

```sh
git submodule update --init --recursive
cd fw
make all BOARD=OLED_4BTN RELEASE=1
```

The OTA package is generated under `fw/_build/`.

Do not flash this build onto LCD or standard three-button OLED hardware.

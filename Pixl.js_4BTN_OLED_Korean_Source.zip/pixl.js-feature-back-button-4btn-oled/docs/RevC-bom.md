| **Id** | **Designator** | **Package** | **Quantity** | **Designation** | **BuyLink** |
|---|---|---|---|---|---|
| 1 | R5,R3 | R_0402_1005Metric | 2 | 10K |  |
| 2 | C6,C3,C16,C2,C10,C5,C7 | C_0402_1005Metric | 7 | 0.1uF |  |
| 3 | U1 | QFN-48-1EP_6x6mm_P0.4mm_EP4.6x4.6mm | 1 | nRF52832-QFxx | [购买地址1 选NRF52832-QFAA](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.2c202e8dYacXja&id=559637973772&_u=r3umvhn0387) |
| 4 | L3 | L_0402_1005Metric | 1 | 3.9nH |  |
| 5 | BT1 | BAT-SMD_CR2032-3V | 1 | Battery_Cell |[购买地址 选CR2032-3电池弹片](https://detail.tmall.com/item.htm?_u=i3umvhn3c4d&id=623218634490&spm=a1z09.2.0.0.40c52e8dLMoPVe)  |
| 6 | C11,C23,C8,C26 | C_0402_1005Metric | 4 | 12pF |  |
| 7 | U4 | MSW | 1 | MSW | [购买地址1](https://item.szlcsc.com/157238.html) \| [购买地址2 按钮两边较长，需稍微剪短](https://item.szlcsc.com/586962.html)  |
| 8 | Y2 | Crystal_SMD_2016-4Pin_2.0x1.6mm | 1 | 32MHz |  |
| 9 | R6 | R_0402_1005Metric | 1 | 1K |  |
| 10 | Y1 | Crystal_SMD_2012-2Pin_2.0x1.2mm | 1 | 32.768K |  |
| 11 | J2 | JST_GH_SM04B-GHS-TB_1x04-1MP_P1.25mm_Horizontal | 1 | Conn_01x04 | [购买地址1 选4p](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.2c202e8dYacXja&id=44160307488&_u=r3umvhn75b1)   |
| 12 | C4 | C_0402_1005Metric | 1 | 4.7uF |  |
| 13 | C13 | C_0402_1005Metric | 1 | 1uF/16V |  |
| 14 | C20,C15 | C_0402_1005Metric | 2 | 180pF |  |
| 15 | R8,R7 | R_0402_1005Metric | 2 | 4.7K |  |
| 16 | U3 | USON-8_3x2mm_0.5pich | 1 | GD25Q16C/ZD25WQ16BUIGR| [购买地址1 低压版 推荐](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.2c202e8dYacXja&id=649864805980&_u=r3umvhn2e64) \| [购买地址2 非低压版](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.2c202e8dYacXja&id=673834706188&_u=r3umvhn2527) |
| 17 | C9 | C_0402_1005Metric | 1 | 10uF |  |
| 18 | AE1 | AN2051 | 1 | Antenna | [购买地址1](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.2c202e8dYacXja&id=558699169012&_u=r3umvhndb66) |
| 19 | C18 | C_0402_1005Metric | 1 | 0.8pF |  |
| 20 | C1 | C_0402_1005Metric | 1 | 1uF |  |
| 21 | C12 | C_0402_1005Metric | 1 | 1uF/25V |  |
| 22 | Q1 | SOT-23 | 1 | AO3400A |  |
| 23 | D1 | LED_0402_1005Metric | 1 | LED_Small |  |
| 24 | J1 | FPC_12 0.8mm | 1 | Conn_01x12 | [屏幕购买地址](https://item.taobao.com/item.htm?spm=a1z09.2.0.0.2c202e8dYacXja&id=660349996995&_u=r3umvhn775a) |
| 25 | AE2 | 40x22MM_NFC_ANTENA | 1 | Antenna_Loop |  |
